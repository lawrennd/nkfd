
% NKFDTOOLBOXES Load in the relevant toolboxes for noisy kernel fishers discriminant.
%
%	Description:
%	% 	nkfdToolboxes.m version 1.2

importLatest('netlab');
importLatest('ndlutil');
importLatest('mltools');
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
