% NKFD toolbox
% Version 0.1		12-Dec-2007
% Copyright (c) 2007, Neil D. Lawrence
% 
, Neil D. Lawrence
% NKFDINVGETNORMAXESPOINT Take a point on a plot and return a point within the figure.
% NLPOST Computes the posteriors for a noiseylabel model
% DEMNKFD1 Demonstration of noise model with Gaussian distributions. First demo in ICML paper.
% NLEM Noisy label EM algorithm for full covariance Gaussian model.
% NKFDPOST Computes the class posterior probabilities of a KFD Model.
% NKFDTOOLBOXES Load in the relevant toolboxes for noisy kernel fishers discriminant.
% DEMNKFD2 Demonstration of noise model with Gaussian distributions. 
% NKFDEM Noisy Kernel Fisher Discriminant EM algorithm.
% DEMNKFDFOURNINE Compare classification of USPS 4 vs 9 for a range of noise values.
% NKFDCLASSVISUALISE Sets up visualisation of decision boundary for NKFD model.
% NKFDACTIV Computes the activations of a KFD Model.
